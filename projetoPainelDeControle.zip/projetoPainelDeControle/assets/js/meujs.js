const handlePhone = (event) => {
    let input = event.target
    input.value = phoneMask(input.value)
}

const phoneMask = (value) => {
    if (!value) return ""
    value = value.replace(/\D/g, '')
    value = value.replace(/(\d)(\d{4})$/, "$1-$2")
    return value
}

const smartPhone = (event) => {
    let input = event.target
    input.value = celMask(input.value)
}
const celMask = (value) => {
    if (!value) return ""
    value = value.replace(/\D/g, '')
    value = value.replace(/(\d)(\d{4})$/, "$1-$2")
    return value
}


function mascara(telefone) {
    if (telefone.value.length == 0)
        telefone.value = '(' + telefone.value; //quando começamos a digitar, o script irá inserir um parênteses no começo do campo.
    if (telefone.value.length == 4)
        telefone.value = telefone.value + ') '; //quando o campo já tiver 3 caracteres (um parênteses e 2 números) o script irá inserir mais um parênteses, fechando assim o código de área.
}

function dinheiro() {
    /* if(dinheiro.value.length == 0){
        dinheiro.value = 'R$ ' + dinheiro.value; //quando começamos a digitar coloca o R$ antes
    } */

    var elemento = document.getElementById('valor');
    var valor = elemento.value;


    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");

    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2"); //coloca as divisoes
    }

    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';

}