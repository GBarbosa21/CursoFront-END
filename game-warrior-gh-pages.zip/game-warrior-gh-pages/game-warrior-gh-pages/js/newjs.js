// Seleciona o botão pelo ID e adiciona um evento de clique a ele
document.getElementById("btn_Registro").addEventListener("click", function() {
    exibirAlerta("Registro efetuado com sucesso!");
});

// Função para exibir o alerta na div de ID "alerta"
function exibirAlerta(mensagem) {
    var divAlerta = document.getElementById("alerta");
    divAlerta.textContent = mensagem;
}
