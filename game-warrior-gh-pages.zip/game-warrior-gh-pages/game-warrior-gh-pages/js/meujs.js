/*   window.onload = function() {
    var nome = prompt("Por favor, insira seu nome:");
    exibirNome(nome);
  }

  function exibirNome(nome) {
    var inserido = document.getElementById("nome");
    inserido.textContent = "Olá, " + nome;
  }
 */