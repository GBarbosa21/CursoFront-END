window.onload = function() {
    var nome = prompt("Por favor, insira seu nome:");
    exibirNome(nome);
  }

  function exibirNome(nome) {
    var nomeInserido = document.getElementById("nomeInserido");
    nomeInserido.textContent = "Olá, " + nome;
  }